package Concesionario;

public class Vendedor {

    private long documento;
    private String nombre;
    private String apellido;
    private int edad;
    private long valorVendido;
    private String descripcion;

    public Vendedor(long documento, String nombre, String apellido, int edad, long valorVendido, String descripcion) {
        this.documento = documento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.valorVendido = valorVendido;
        this.descripcion = descripcion;
    }

    public long getDocumento() {
        return documento;
    }

    private void setDocumento(long documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    private void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    private void setEdad(int edad) {
        this.edad = edad;
    }

    public long getValorVendido() {
        return valorVendido;
    }

    private void setValorVendido(long valorVendido) {
        this.valorVendido = valorVendido;
    }

    public String getDescripcion() {
        return descripcion;
    }

    private void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}
