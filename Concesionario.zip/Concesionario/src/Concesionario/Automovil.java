package Concesionario;

public class Automovil {

    private String placa;
    private String marca;
    private String modelo;
    private int kilometraje;
    private String color;
    private int precio;
    private String descripcion;

    public Automovil() {
    }

    public Automovil(String placa, String marca, String modelo, int kilometraje, String color, int precio, String descripción) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometraje = kilometraje;
        this.color = color;
        this.precio = precio;
        this.descripcion = descripción;
    }

    public String getPlaca() {
        return placa;
    }

    private void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    private void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    private void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getKilometraje() {
        return kilometraje;
    }

    private void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }

    public String getColor() {
        return color;
    }

    private void setColor(String color) {
        this.color = color;
    }

    public int getPrecio() {
        return precio;
    }

    private void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    private void setDescripción(String descripción) {
        this.descripcion = descripción;
    }

}
