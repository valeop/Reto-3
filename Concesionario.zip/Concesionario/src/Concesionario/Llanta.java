package Concesionario;

public class Llanta {

    private String marca;
    private String referencia;
    private double peso;

    public Llanta() {

    }

    public Llanta(String marca, String referencia, double peso) {
        this.marca = marca;
        this.referencia = referencia;
        this.peso = peso;
    }

    public String getMarca() {
        return marca;
    }

    private void setMarca(String marca) {
        this.marca = marca;
    }

    public String getReferencia() {
        return referencia;
    }

    private void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public double getPeso() {
        return peso;
    }

    private void setPeso(int peso) {
        this.peso = peso;
    }

}
