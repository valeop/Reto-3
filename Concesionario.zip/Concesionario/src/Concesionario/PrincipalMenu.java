package Concesionario;

import java.util.Scanner;
import java.util.Arrays;

public class PrincipalMenu {

    public static String placa;
    protected static String marca;
    public static String modelo;
    public static int kilometraje;
    public static String color;
    public static int precio;
    protected static String descripcion;
    public static int cilindraje;
    public static String referencia;
    public static double peso;
    public static long documento;
    public static String nombre;
    public static String apellido;
    public static int edad;
    public static long valorVendido;
    public static int añoVehiculo;
    public static int añoEmpresa;
    public static int contador = 1;
    public static int limite = 0;
    public static Object llantas[][] = new Object[4][3];

    public static void main(String[] args) {
        Scanner dato = new Scanner(System.in);
        System.out.println("SISTEMA DE VENTAS DE CONCESIONARIOS (SOLO PARA EMPLEADOS)\n\n");
        System.out.println("Por favor ingresa los siguientes datos del carro:\n");
        System.out.print("Placa (Números y letras): ");
        placa = dato.next();
        System.out.print("\nMarca (Letras y números): ");
        marca = dato.next();
        System.out.print("\nModelo (Letras y números): ");
        modelo = dato.next();
        System.out.print("\nKilometraje (Números): ");
        kilometraje = dato.nextInt();
        System.out.print("\nColor (Letras): ");
        color = dato.next();
        System.out.print("\nPrecio(COP): ");
        precio = dato.nextInt();
        System.out.print("\nBreve descripción: ");
        descripcion = dato.next();
        System.out.print("\nAño de Fabricación: ");
        añoVehiculo = dato.nextInt();
        System.out.println(añoVehiculo);
        Automovil auto = new Automovil(placa, marca, modelo, kilometraje, color, precio, descripcion);

        System.out.println("\n\nPor favor ingresa los siguientes datos del MOTOR:\n");
        System.out.print("Cilindraje (Números): ");
        cilindraje = dato.nextInt();
        System.out.print("\nMarca (Letras y números): ");
        marca = dato.next();
        System.out.print("\nReferencia (Letras y números): ");
        referencia = dato.next();
        System.out.print("\nPeso (kg | usar la coma (,) para decimales): ");
        peso = dato.nextDouble();
        System.out.print("\nBreve descripción: ");
        descripcion = dato.next();
        Motor obM = new Motor(cilindraje, marca, referencia, peso, descripcion);

        System.out.println("\n\nPor favor ingresa los siguientes datos para las cuatro (4) LLANTAS:\n");

        for (int i = 1; i <= 4; i++) {
            System.out.println("\n Para la llanta N° " + i + ": \n");
            System.out.print("Marca (Letras y números): ");
            marca = dato.next();
            System.out.print("\nReferencia (Letras y números): ");
            referencia = dato.next();
            System.out.print("\nPeso (kg | usar la coma (,) para decimales): ");
            peso = dato.nextDouble();
            Llanta obL = new Llanta(marca, referencia, peso);
            llantas[limite][0] = obL.getMarca();
            llantas[limite][1] = obL.getReferencia();
            llantas[limite][2] = obL.getPeso();
            limite++;
        }

        System.out.println("\n\nPor favor ingresa los datos del VENDEDOR que se hará cargo de la venta de este vehículo:\n");
        System.out.print("Documento (Números): ");
        documento = dato.nextLong();
        System.out.print("\nNombre/s (Letras): ");
        nombre = dato.next();
        System.out.print("\nApellido/s (Letras): ");
        apellido = dato.next();
        System.out.print("\nEdad (Números): ");
        edad = dato.nextInt();
        System.out.print("\nTotal vendido (Números): ");
        valorVendido = dato.nextInt();
        System.out.print("\nBreve descripción: ");
        descripcion = dato.next();
        System.out.print("\nAño en el que " + nombre + " " + apellido + " ingresó a la empresa: ");
        añoEmpresa = dato.nextInt();
        Vendedor obV = new Vendedor(documento, nombre, apellido, edad, valorVendido, descripcion);

        System.out.println("\n\nRESULTADOS PARA EL VEHÍCULO: \n");
        System.out.println("Placa: " + auto.getPlaca());
        System.out.println("Marca: " + auto.getMarca());
        System.out.println("Modelo: " + auto.getModelo());
        System.out.println("Kilometraje: " + auto.getKilometraje() + " km");
        System.out.println("Color: " + auto.getColor());
        System.out.println("Precio: " + auto.getPrecio() + " COP");
        System.out.println("Descripción: " + auto.getDescripcion());
        System.out.println("Año de Fabricacion: " + añoVehiculo);

        System.out.println("\n\nRESULTADOS PARA EL MOTOR: \n");
        System.out.println("Cilindraje: " + obM.getCilindraje() + " cc");
        System.out.println("Marca: " + obM.getMarca());
        System.out.println("Referencia: " + obM.getReferencia());
        System.out.println("Peso: " + obM.getPeso() + " kg");
        System.out.println("Descripción: " + obM.getDescripcion());

        System.out.println("\n\nRESULTADOS PARA LAS LLANTAS: \n");
        for (int recorre = 0; recorre <= 3; recorre++) {
            System.out.println("\nLlanta N° " + contador + ":");
            System.out.println("Marca: " + llantas[recorre][0]);
            System.out.println("Referencia: " + llantas[recorre][1]);
            System.out.println("Peso: " + llantas[recorre][2] + " kg \n");
        }
        Calculos op = new Calculos();
        System.out.println("\nEl estado del vehículo basado en su kilometraje es: " + op.usoAuto(auto.getKilometraje()));
        System.out.println("La edad del vehículo basada en el año de fabricación es: " + op.añoFabrica(añoVehiculo));

        System.out.println("\n\nDATOS DEL VENDEDOR ENCARGADO DE ESTE VEHÍCULO: \n");
        System.out.println("Documento: " + obV.getDocumento());
        System.out.println("Nombre/s: " + obV.getNombre());
        System.out.println("Apellido/s: " + obV.getApellido());
        System.out.println("Edad: " + obV.getEdad());
        System.out.println("Total vendido en la empresa: " + obV.getValorVendido());
        System.out.println("Nombre/s: " + obV.getNombre());
        System.out.println("Descripción: " + obV.getDescripcion());

        System.out.println("\nExperiencia en ventas basada en el total vendido: " + op.nivelVentas(obV.getValorVendido()));
        System.out.println("Nivel del vendedor basado en el tiempo que lleva dentro de la empresa y el valor total vendido: " + op.nivelTiempo(añoEmpresa, obV.getValorVendido()));
        System.out.println("\n\n¡PROCESO FINALIZADO!");
    }

}
