package Concesionario;

public class Motor {

    private int cilindraje;
    private String marca;
    private String referencia;
    private double peso;
    private String descripcion;

    public Motor() {

    }

    public Motor(int cilindraje, String marca, String referencia, double peso, String descripcion) {
        this.cilindraje = cilindraje;
        this.marca = marca;
        this.referencia = referencia;
        this.peso = peso;
        this.descripcion = descripcion;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    private void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    public String getMarca() {
        return marca;
    }

    private void setMarca(String marca) {
        this.marca = marca;
    }

    public String getReferencia() {
        return referencia;
    }

    private void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public double getPeso() {
        return peso;
    }

    private void setPeso(int peso) {
        this.peso = peso;
    }

    public String getDescripcion() {
        return descripcion;
    }

    private void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}
