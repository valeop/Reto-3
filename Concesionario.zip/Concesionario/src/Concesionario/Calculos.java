package Concesionario;

import java.time.LocalDate;

public class Calculos {

    public String usoAuto(int kilometraje) {
        String uso = null;

        if (kilometraje == 0) {
            uso = "0 Km";
        } else if (kilometraje > 0 && kilometraje <= 1000) {
            uso = "NUEVO";
        } else if (kilometraje > 1000 && kilometraje <= 20000) {
            uso = "CASI NUEVO";
        } else if (kilometraje > 20000 && kilometraje <= 100000) {
            uso = "USADO";
        } else if (kilometraje > 100000) {
            uso = "MUY USADO";
        }
        return uso;
    }

    public String nivelVentas(long ventas) {
        String nivel = null;
        if (ventas == 0) {
            nivel = "NOVATO";
        } else if (ventas > 0 && ventas <= 500000000) {
            nivel = "PRINCIPIANTE";
        } else if (ventas > 500000000 && ventas <= 2000000000) {
            nivel = "INTERMEDIO";
        } else if (ventas > 2000000000) {
            nivel = "AVANZADO";
        }
        return nivel;
    }

    public String nivelTiempo(int añoInicio, long dinero) {
        LocalDate año = LocalDate.now();
        String nivel = null;
        int años = año.getYear() - añoInicio;
        double total = dinero / años;
        total = (total * 100) / dinero;
        if (total < 10) {
            nivel = "MALO";
        } else if (total > 10 && total <= 15) {
            nivel = "REGULAR";
        } else if (total > 15 && total <= 20) {
            nivel = "BUENO";
        } else if (total > 20) {
            nivel = "EXCELENTE";
        }
        return nivel;
    }

    public String añoFabrica(int añoCarro) {
        String estado = null;
        LocalDate año = LocalDate.now();
        int edad = año.getYear() - añoCarro;
        if (edad >= 20) {
            estado = "ANTIGUO";
        } else if (edad >= 10 && edad < 20) {
            estado = "INTERMEDIO";
        } else if (edad >= 5 && edad < 10) {
            estado = "NUEVO";
        } else if (edad >= 0 && edad < 5) {
            estado = "ULTIMO MODELO";
        }
        return estado;
    }

}
